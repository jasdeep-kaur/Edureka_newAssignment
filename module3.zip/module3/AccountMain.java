package com.edureka.module3;

import java.util.Scanner;

abstract class Account {
	long accountNumber;
	String accountName;
	int amount;

	Account(long accountNumber, String accountName, int ammount) {
		this.accountNumber = accountNumber;
		this.accountName = accountName;
		this.amount = amount;
	}

	public void deposit(int ammount, int rate) {
		System.out.println("The Total amount deposited is: " + amount + (amount * rate) / 1200);
	}

	public int withdraw() {
		return this.amount;
	}

}

class SBAccount extends Account {

	private int interest = 4;
	private final long min_balance = 10000;

	SBAccount(long accountNumber, String accountName, int ammount) {
		super(accountNumber, accountName, ammount);
	}
}

class Current_Account extends Account {

	// private int interest=4;
	private final long min_balance = 50000;

	Current_Account(long accountNumber, String accountName, int ammount) {
		super(accountNumber, accountName, ammount);
	}
}

public class AccountMain{
	public static void main(){
		Scanner s=new Scanner(System.in);
		System.out.println("Enter Account Type:");
		String accType=s.nextLine();
		if(accType.equalsIgnoreCase("SB_ACCOUNT")){
			Account sbAccount=new SBAccount(112212121212l, "FameIssrani", 60000); 
			
		}else if(accType.equalsIgnoreCase("SB_ACCOUNT")){
			Account reAccount=new Current_Account(221334212321l, "FameIssrani", 332121); 
		}else{
			System.out.println("Invalid Account Type");
		}
	}
}

