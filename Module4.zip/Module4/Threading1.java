package Module4;

/**
 * Created by jasdeepkaur on 3/15/17.
 */
public class Threading1 implements Runnable
{

    public void run()
    {

        for ( int i=1; i<=40; i++)
        {
            if(i%2==0)
            {
                System.out.println(i);
            }
        }
    }
}
