
//Write a program to define a queue interface and have insert and delete methods in the
//interface. Implement these methods in a class.

package Module4;

/**
 * Created by jasdeepkaur on 3/15/17.
 */
import java.util.LinkedList;
import java.util.Queue;

public class QueueImpl
{
    public static void main(String[] args)
    {
        Queue<Integer> q = new LinkedList<>();

        for (int i=0; i<5; i++)
            q.add(i);

        System.out.println("Elements of queue-"+q);

        int removedelete = q.remove();
        System.out.println("removed element-" + removedelete);

        System.out.println(q);

        int head = q.peek();
        System.out.println("head of queue->" + head);

        int size = q.size();
        System.out.println("Size of queue->" + size);
    }
}
