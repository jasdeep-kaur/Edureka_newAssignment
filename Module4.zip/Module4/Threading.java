// Write a program to print tables of 5 by creating a new thread and display 20 even numbers as a task of main thread.

package Module4;

/**
 * Created by jasdeepkaur on 3/15/17.
 */
public class Threading implements Runnable
{


    public void run()
    {
    for ( int i=1; i<=10; i++)
        {
            System.out.println("5*"+i+"="+5*i);

        }
    }
}
