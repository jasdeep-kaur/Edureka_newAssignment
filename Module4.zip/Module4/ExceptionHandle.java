
//Write a program to demonstrate ArrayIndexOutOfBoundsException

package Module4;

/**
 * Created by jasdeepkaur on 3/15/17.
 */
public class ExceptionHandle {

    public static void main(String[] args)
    {
        int[] arr = {1,2,3,4,5};
        for(int i=0;i<=5;i++)
        {
            System.out.println(arr[i]);

        }

    }

}

