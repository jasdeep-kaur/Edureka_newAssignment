package Module4;


/**
 * Created by jasdeepkaur on 3/15/17.
 */
public class MainThread {
    public static void main(String args[])
    {
        Threading firstThread = new Threading();
        Threading1 secondThread = new Threading1();

        Thread thread1 = new Thread(firstThread);
        thread1.start();

        Thread thread2 = new Thread(secondThread);
        thread2.start();
    }
}
