package com.edureka.module2;

import java.util.Scanner;

class Q_One{
	
	public void display(int[] id,String name[], int[] salary ){
		System.out.println("\t ID \t Name \t Salary");
		for(int i=0;i<id.length;i++){
			System.out.println("\t"+ id[i]+" \t "+name[i]+" \t "+salary[i]);
		}
		
	}
	public void display(int[] id,String name[]){
		System.out.println("\t ID \t Name ");
		for(int i=0;i<id.length;i++){
			System.out.println("\t"+ id[i]+" \t "+name[i]);
		}
		
	}
	
	public void display(String nameVal,int[] id,String name[],int[] salary){
		boolean flag=false;
		int i=0;
		while(!flag){
			if(name[i]==nameVal){
				flag=true;
				break;
			}
			i++;
			if(flag==false){
				System.out.println("Entered Name Does Not Exists");
				return;
			}
			System.out.println("\t ID \t Name \t Salary");
	
			System.out.println("\t"+ id[i]+" \t "+name[i]+"\t"+salary[i]);
	}
	
}
}

public class Q_OneMain{
	public static void main(String[] args){
		int[] id=null, salary=null;
		String[] name=null;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter ID, Name, Salary");
		for(int i=0;i<6;i++){
			System.out.println("Enter ID:");
			id[i]=s.nextInt();
			System.out.println("Enter Name:");
			name[i]=s.nextLine();
			System.out.println("Enter Salary: ");
			salary[i]=s.nextInt();
			Q_One one=new Q_One();
			one.display(id,name,salary);
			one.display(id, name);
			
			System.out.println("Enter the name to be searched");
			String nameVal=s.nextLine();
			
				
				
			}
		}
}
