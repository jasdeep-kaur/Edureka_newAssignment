package Module1_While;

import java.util.Scanner;

/**
 * Created by jasdeepkaur on 3/16/17.
 */
public class EvenOdd {
    public static void main(String[] aa) {
        Scanner sc=new Scanner(System.in);
        System.out.println("the list of even no.");

        int i=0;
        while(i<=20)
        {
            if (i % 2 == 0)
                System.out.println(i);
             i++;

        }
        System.out.println("the list of odd no.");
        int j=0;
        while(j<=20)
        {
            if(j%2!=0)
                System.out.println(j);
            j++;
        }

    }
}
