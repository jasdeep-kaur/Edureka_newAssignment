package Module1_While;

import java.util.Scanner;

/**
 * Created by jasdeepkaur on 3/16/17.
 */
public class Table {
    public static void main(String[] aa)
    {
        Scanner sc=new Scanner(System.in);
        int res=0;
        System.out.println("Enter the no.");
        int x=sc.nextInt();
        int i=1;

        while(i<=10)
        {

            res = x * i;
            System.out.println("1."+x+"*"+i+"="+res);
           i++;
        }
    }
}
