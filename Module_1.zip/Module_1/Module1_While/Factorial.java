package Module1_While;

import java.util.Scanner;

/**
 * Created by jasdeepkaur on 3/16/17.
 */
public class Factorial {
    public static void main(String args[]) {
        System.out.println("enter the no.");
        Scanner sc = new Scanner(System.in);
        int i = 1;

        int number = sc.nextInt();
        int fact = 1;
        while (i <= number)
        {
            fact = fact * i;
            i++;
        }


        System.out.println("Factorial of " + number + " is: " + fact);
    }
}