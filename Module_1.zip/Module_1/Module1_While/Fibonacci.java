package Module1_While;

import java.util.Scanner;

/**
 * Created by jasdeepkaur on 3/16/17.
 */
public class Fibonacci {
    public static void main(String[] aa)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the no.");
        int x= sc.nextInt();

        int f1=0,f2=1;
        int f3;
        System.out.print(f1+" "+f2);
        int i=1;
        while(i<=x)
        {
            f3=f1+f2;


            f2=f3;
            f1=f2;
           System.out.print(" "+f1+" ");
            i++;
        }

    }
}

