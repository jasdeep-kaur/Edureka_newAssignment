package Module1_doWhile;

import java.util.Scanner;

/**
 * Created by jasdeepkaur on 3/16/17.
 */
public class EvenOdd {
    public static void main(String[] aa) {
        Scanner sc=new Scanner(System.in);
        System.out.println("the list of even no.");

        int i=0;

        do{
            if (i % 2 == 0)
                System.out.println(i);
            i++;

        }while(i<=20);
        System.out.println("the list of odd no.");
        int j=0;

        do{
            if(j%2!=0)
                System.out.println(j);
            j++;
        }while(j<=20);

    }
}
