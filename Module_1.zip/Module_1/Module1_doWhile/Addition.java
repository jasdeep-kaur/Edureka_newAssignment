package Module1_doWhile;

import java.util.Scanner;

/**
 * Created by jasdeepkaur on 3/16/17.
 */
public class Addition {
    public static void main(String args[])
    {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Addition of Numbers ");
        System.out.println( " \n" );

        System.out.println( "Number: " );
        int number = keyboard.nextInt();
        int sum = 0;
        int run=1;
        //for (int run=1; run<=number; run=run+1)

        do{
            System.out.print( run + " " );
            sum = sum + run;
            run++;
        } while(run<=number);

        System.out.println( "The sum is " + sum );

    }
}
