package Module1_doWhile;

import java.util.Scanner;

/**
 * Created by jasdeepkaur on 3/16/17.
 */
public class Reverse {
    public static void main(String aa[])
    {
        Scanner sc=new Scanner(System.in);
        int a,s=0;
        System.out.println("enter the value of a");
        a=sc.nextInt();


        do{
            s = s*10;
            s = s + (a%10);
            a=a/10;
        }  while(a>0);
        System.out.println("the reverse " +s);
    }
}
