package Module1_if;

import java.util.Scanner;

/**
 * Created by jasdeepkaur on 3/16/17.
 */
public class IfElseCondition {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the valure=");
        int age = sc.nextInt();


        if(age == 0)
        {
            System.out.println("zero");
        }else if (age < 0) {
            System.out.println(" negative");
        } else if(age>0) {
            System.out.println("positive");
        }

    }



}
