package Module1_if;

import java.util.Scanner;

/**
 * Created by jasdeepkaur on 3/16/17.
 */
public class pos_neg {

        public static void main(String args[]) {
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter the valure=");
            int age = sc.nextInt();

            if (age < 0) {
                System.out.println(" negative");
            } else {
                System.out.println("positive");
            }
        }


}
