package Module1_if;

import java.util.Scanner;

/**
 * Created by jasdeepkaur on 3/16/17.
 */
public class EvenOdd {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the value");
        int a = sc.nextInt();

        if (a%2==0) {
            System.out.println("even");
        } else {
            System.out.println("odd");
        }
    }
}
