package Module1_if;

import java.util.Scanner;

/**
 * Created by jasdeepkaur on 3/16/17.
 */
public class Voting {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the age of the person");
        int age = sc.nextInt();

        if (age < 21) {
            System.out.println(" not elligible");
        } else {
            System.out.println("elligible");
        }
    }
}
