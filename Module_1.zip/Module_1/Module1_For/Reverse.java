package Module1_For;

import java.util.Scanner;

/**
 * Created by jasdeepkaur on 3/16/17.
 */
public class Reverse {
    public static void main(String aa[])
    {
        Scanner sc=new Scanner(System.in);
        int a,s;
        System.out.println("enter the value of a");
        a=sc.nextInt();
        for(s=0;a>0;a=a/10)
        {
            s = s*10;
            s = s + (a%10);
        }
        System.out.println("the reverse " +s);
    }
}
