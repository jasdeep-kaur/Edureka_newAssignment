package Module1_For;

import java.util.Scanner;

/**
 * Created by jasdeepkaur on 3/16/17.
 */
public class EvenOdd {
    public static void main(String[] aa) {
        Scanner sc=new Scanner(System.in);
        System.out.println("the list of even no.");
        for (int i = 0; i <= 20; i++)
        {
            if (i % 2 == 0)
                System.out.println(i);


        }
        //Scanner sc= new Scanner(System.in);
       System.out.println("the list of odd no.");
//        int x=sc.nextInt();
//        int y=sc.nextInt();

        for(int i=0;i<=20;i++)
        {
            if(i%2!=0)
                System.out.println(i);
        }

    }
    }