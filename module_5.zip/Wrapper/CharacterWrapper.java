package Wrapper;

/**
 * Created by jasdeepkaur on 3/15/17.
 */
public class CharacterWrapper {
    public static void main (String args[]){
        Character cobj1 = new Character ('b');
        Character cobj2=new Character('c');
        Character cobj3=new Character('d');
        //Character cobj4= new Character ('e');

        System.out.println("Comparing using compareTo Obj1 and Obj2: " + cobj1.compareTo(cobj2));
        System.out.println("Comparing using compareTo Obj1 and Obj3: " + cobj1.compareTo(cobj3));

        System.out.println("Comparing using equals Obj1 and Obj2: " + cobj1.equals(cobj2));
        System.out.println("Comparing using equals Obj1 and Obj3: " + cobj1.equals(cobj3));



    }
}
