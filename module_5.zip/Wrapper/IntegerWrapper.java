package Wrapper;

/**
 * Created by jasdeepkaur on 3/15/17.
 */
public class IntegerWrapper{
    public static void main (String args[]){
        Integer intObj1 = new Integer (25);
        Integer intObj2 = new Integer (25);
        Integer intObj3= new Integer (35);

        System.out.println("Comparing using compareTo Obj1 and Obj2: " + intObj1.compareTo(intObj2));
        System.out.println("Comparing using compareTo Obj1 and Obj3: " + intObj1.compareTo(intObj3));

        System.out.println("Comparing using equals Obj1 and Obj2: " + intObj1.equals(intObj2));
        System.out.println("Comparing using equals Obj1 and Obj3: " + intObj1.equals(intObj3));

        Integer intWrapper = Integer.valueOf("12345");

        Integer intWrapper2 = Integer.valueOf("11011", 2);

        Integer intWrapper3 = Integer.valueOf("D", 16);
        System.out.println("\n Value of intWrapper Object: "+ intWrapper);
        System.out.println("Value of intWrapper2 Object: "+ intWrapper2);
        System.out.println("Value of intWrapper3 Object: "+ intWrapper3);
        System.out.println("Hex value of intWrapper: " + Integer.toHexString(intWrapper));
        System.out.println("Binary Value of intWrapper2: "+ Integer.toBinaryString(intWrapper2));


    }

}
