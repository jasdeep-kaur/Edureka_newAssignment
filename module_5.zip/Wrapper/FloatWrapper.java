package Wrapper;

/**
 * Created by jasdeepkaur on 3/15/17.
 */
public class FloatWrapper {
//    public static void main (String args[]){
//        Float floatObj1=new Float(1.25);
//        Float floatObj2=new Float(2.25);
//        Float floatObj3=new Float(3.25);
//
//        System.out.println("Comparing using compareTo Obj1 and Obj2: " + floatObj1.compareTo(floatObj2));
//        System.out.println("Comparing using compareTo Obj1 and Obj3: " + floatObj1.compareTo(floatObj3));
//
//        System.out.println("Comparing using equals Obj1 and Obj2: " + floatObj1.equals(floatObj3));
//        System.out.println("Comparing using equals Obj1 and Obj3: " + floatObj1.equals(floatObj3));
//
//        Float floatObj=String.valueOf("0.25");
//        Integer intWrapper2 = Integer.valueOf("11011", 2);
//
//        Integer intWrapper3 = Integer.valueOf("D", 16);
//        System.out.println("\n Value of intWrapper Object: "+ intWrapper);
//        System.out.println("Value of intWrapper2 Object: "+ intWrapper2);
//        System.out.println("Value of intWrapper3 Object: "+ intWrapper3);
//        System.out.println("Hex value of intWrapper: " + Integer.toHexString(intWrapper));
//        System.out.println("Binary Value of intWrapper2: "+ Integer.toBinaryString(intWrapper2));
//
//
//    }
}
