package Module4;
//import java.util.Function;


import Functions.Calculation;

/**
 * Created by jasdeepkaur on 3/16/17.
 */
public class MainFunction {
    public static void main(String args[])
    {
    Calculation cal=new Calculation();
    cal.Reverse();
    cal.Subtract();
    cal.Multiply();
    cal.Divide();
    cal.Fibonacci();}
}
